<?php

include_once(__DIR__ . "/classes/autoload.php");

echo CBase::getParam('message');